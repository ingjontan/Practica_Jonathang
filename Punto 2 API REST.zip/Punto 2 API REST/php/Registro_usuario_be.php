<?php

    include 'conexion_be.php';

    $Full_name = $_POST['Full_name'];
    $email = $_POST['email'];
    $user = $_POST['user'];
    $password = $_POST['password'];

    $query = "INSERT INTO usuarios(Full_Name, Email, User, Password" 
                values ('$Full_name', 'email', 'user', 'password');

    $ejecutar = mysqli_query($conexion, $query);

    if($ejecutar)
        echo '
            <script>
                alert("Usuario almacenado exitosamente");
                window.location = "../index.php";
            </script>
            ';

            mysqli_close($conexion);
?>
