<?php

    $conexion = mysqli_connetc("localhost", "root", "Petrol.123", "libreta_contacto");

    if($conexion){
        echo 'conectado a la DBA';
}else {
    'NO Conexion a la DBA';
}


?>